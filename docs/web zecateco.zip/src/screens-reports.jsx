// Reports: Registros em tempo real, Info reg (with date modal), Relatório (with date modal)

const RTColumns = [
  { k: "hora",     l: "Hora",      mono: true, w: "180px" },
  { k: "id",       l: "ID",        mono: true, w: "90px"  },
  { k: "nome",     l: "Nome" },
  { k: "identif",  l: "Identific." },
  { k: "inout",    l: "inout" },
  { k: "evento",   l: "Evento" },
  { k: "not",      l: "not" },
  { k: "photo",    l: "photo" }
];

const RealtimeScreen = () => {
  useLucide();
  const [rows, setRows] = React.useState(window.UPSeed.seedRealtime);
  const [search, setSearch] = React.useState("");

  // Auto-tick: tail a new log every 8 seconds for vibe
  React.useEffect(() => {
    const id = setInterval(() => {
      setRows(prev => {
        if (prev.length > 30) return prev;
        const u = window.UPSeed.seedUsers[Math.floor(Math.random() * window.UPSeed.seedUsers.length)];
        const now = new Date().toISOString().replace("T", " ").slice(0, 19);
        return [{
          hora: now, id: u.id, nome: u.nome,
          identif: ["Face", "Senha", "Cartão"][Math.floor(Math.random() * 3)],
          inout: "in", evento: "Entrada", not: "OK", photo: Math.random() > .4
        }, ...prev];
      });
    }, 8000);
    return () => clearInterval(id);
  }, []);

  const filtered = rows.filter(r => !search || r.nome.toLowerCase().includes(search.toLowerCase()) || String(r.id).includes(search));

  return (
    <div className="p-6 space-y-3">
      <div className="up-card p-3 flex items-center gap-2">
        <span className="inline-flex items-center gap-2 text-[12.5px] text-ink-500 mr-auto">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 pulse-dot"></span>
          Streaming em tempo real
        </span>
        <div className="relative">
          <input className="field pl-8 w-56" placeholder="Search" value={search} onChange={e => setSearch(e.target.value)} />
          <Icon name="search" size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-400" />
        </div>
        <button className="btn-ghost p-2 h-9 w-9 justify-center"><Icon name="calendar" size={14} /></button>
        <button className="btn-ghost p-2 h-9 w-9 justify-center"><Icon name="refresh-cw" size={14} /></button>
        <button className="btn-ghost p-2 h-9 w-9 justify-center"><Icon name="layout-grid" size={14} /></button>
        <button className="btn-ghost p-2 h-9 w-9 justify-center"><Icon name="sliders-horizontal" size={14} /></button>
      </div>

      <div className="up-card overflow-hidden">
        <div className="overflow-x-auto nice-scroll">
          <table className="w-full border-collapse min-w-[900px]">
            <thead>
              <tr className="bg-up-500 text-white">
                {RTColumns.map(c => (
                  <th key={c.k} className="up-th text-left" style={{ width: c.w }}>{c.l} <Icon name="chevrons-up-down" size={11} className="inline ml-0.5 opacity-70" /></th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={8} className="py-12 text-center text-ink-400 text-[13px]">Nenhum registro encontrado</td></tr>
              ) : filtered.map((r, i) => (
                <tr key={i} className="up-row border-b border-ink-200 dark:border-[#222A36]">
                  <td className="up-td font-mono tabular">{r.hora}</td>
                  <td className="up-td font-mono tabular">{r.id}</td>
                  <td className="up-td font-medium text-ink-900 dark:text-white">{r.nome}</td>
                  <td className="up-td">
                    <span className="inline-flex items-center gap-1 text-[11.5px] font-medium bg-up-50 text-up-700 px-1.5 py-0.5 rounded">
                      <Icon name={r.identif === "Face" ? "scan-face" : r.identif === "Cartão" ? "credit-card" : "key-round"} size={11} /> {r.identif}
                    </span>
                  </td>
                  <td className="up-td">
                    <span className={`text-[11.5px] font-semibold px-1.5 py-0.5 rounded ${r.inout === "in" ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"}`}>{r.inout}</span>
                  </td>
                  <td className="up-td">{r.evento}</td>
                  <td className="up-td">
                    <span className="inline-flex items-center gap-1 text-emerald-600 text-[12px] font-medium"><Icon name="check-circle-2" size={12} /> {r.not}</span>
                  </td>
                  <td className="up-td">
                    {r.photo
                      ? <span className="inline-flex items-center gap-1 text-ink-500 text-[12px]"><Icon name="image" size={12} /> ver</span>
                      : <span className="text-ink-300 text-[12px]">—</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const DateModal = ({ title, onSubmit, onClose, withId = true }) => {
  const [v, setV] = React.useState({ id: "", inicio: "", fim: "" });
  useLucide();
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center modal-back bg-ink-900/30 dark:bg-black/50">
      <div className="up-card w-[420px] overflow-hidden">
        <div className="bg-up-50 dark:bg-[#1B2230] border-b border-up-100 dark:border-[#222A36] px-4 py-3 flex items-center">
          <h3 className="text-up-700 dark:text-up-300 font-semibold text-[14px]">{title}</h3>
          <button className="ml-auto p-1 rounded hover:bg-up-100/60 text-up-700" onClick={onClose}><Icon name="x" size={14} /></button>
        </div>
        <div className="p-5 space-y-3">
          {withId && (
            <div>
              <label className="label">ID</label>
              <input className="field tabular" placeholder="todos" value={v.id} onChange={e => setV({ ...v, id: e.target.value })} />
            </div>
          )}
          <div>
            <label className="label">Início:</label>
            <input type="date" className="field" value={v.inicio} onChange={e => setV({ ...v, inicio: e.target.value })} />
          </div>
          <div>
            <label className="label">Fim:</label>
            <input type="date" className="field" value={v.fim} onChange={e => setV({ ...v, fim: e.target.value })} />
          </div>
        </div>
        <div className="flex justify-end gap-2 p-3 border-t border-ink-200 dark:border-[#222A36] bg-ink-50 dark:bg-[#0E1117]">
          <button className="btn-ghost" onClick={onClose}>CANCELAR</button>
          <button className="btn-primary" onClick={() => onSubmit && onSubmit(v)}><Icon name="send" size={13} />ENVIAR</button>
        </div>
      </div>
    </div>
  );
};

const InfoRegScreen = () => {
  useLucide();
  const [showModal, setShowModal] = React.useState(true);
  const [rows, setRows] = React.useState([]);

  return (
    <div className="p-6 space-y-3">
      <div className="up-card p-3 flex flex-wrap items-center gap-2">
        <button className="btn-danger"><Icon name="trash-2" size={13} />Apagar registros</button>
        <button className="btn-outline"><Icon name="file-down" size={13} />Salvar logs como CSV</button>
        <button className="btn-outline"><Icon name="file-up" size={13} />Carregar logs de CSV</button>
        <button className="btn-soft" onClick={() => setShowModal(true)}><Icon name="calendar-range" size={13} />Filtrar por data</button>
        <span className="text-[12px] text-rose-600 ml-2">Essas funções são usadas para agregar registros de vários dispositivos em um único dispositivo e, então, gerar relatórios.</span>
      </div>

      <div className="up-card overflow-hidden">
        <table className="w-full border-collapse min-w-[900px]">
          <thead>
            <tr className="bg-up-500 text-white">
              {RTColumns.map(c => (<th key={c.k} className="up-th text-left">{c.l}</th>))}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr><td colSpan={8} className="py-16 text-center text-ink-400 text-[13px]">No matching records found</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {showModal && <DateModal title="Info reg" onClose={() => setShowModal(false)} onSubmit={(v) => {
        setShowModal(false);
        // populate with mock filtered logs
        setRows(window.UPSeed.seedRealtime.slice(0, 5));
      }} />}
    </div>
  );
};

const RelatorioScreen = () => {
  useLucide();
  const [showModal, setShowModal] = React.useState(true);
  const [rows, setRows] = React.useState([]);
  const [meta, setMeta] = React.useState(null);

  return (
    <div className="p-6 space-y-3">
      <div className="up-card p-3 flex flex-wrap items-center gap-2">
        <button className="btn-soft" onClick={() => setShowModal(true)}><Icon name="calendar-range" size={13} />Selecionar período</button>
        <button className="btn-outline"><Icon name="file-down" size={13} />Exportar PDF</button>
        <button className="btn-outline"><Icon name="file-spreadsheet" size={13} />Exportar Excel</button>
        <button className="btn-outline"><Icon name="printer" size={13} />Imprimir</button>
        {meta && (
          <span className="ml-auto text-[12.5px] text-ink-500">
            Período: <span className="font-semibold text-ink-900 dark:text-white">{meta.inicio || "—"} até {meta.fim || "—"}</span>
          </span>
        )}
      </div>

      {/* Summary KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        {[
          { l: "Registros", v: rows.length, icon: "list" },
          { l: "Únicos",    v: new Set(rows.map(r => r.id)).size, icon: "users" },
          { l: "Entradas",  v: rows.filter(r => r.inout === "in").length, icon: "log-in" },
          { l: "Saídas",    v: rows.filter(r => r.inout === "out").length, icon: "log-out" }
        ].map(k => (
          <div key={k.l} className="up-card p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-up-50 text-up-600 flex items-center justify-center"><Icon name={k.icon} size={16} /></div>
            <div>
              <div className="text-[11.5px] uppercase tracking-wider text-ink-500 font-semibold">{k.l}</div>
              <div className="text-[22px] font-bold text-ink-900 dark:text-white tabular leading-tight">{k.v}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="up-card overflow-hidden">
        <table className="w-full border-collapse min-w-[900px]">
          <thead>
            <tr className="bg-up-500 text-white">
              {RTColumns.map(c => (<th key={c.k} className="up-th text-left">{c.l}</th>))}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr><td colSpan={8} className="py-16 text-center text-ink-400 text-[13px]">Selecione um período para gerar o relatório</td></tr>
            ) : rows.map((r, i) => (
              <tr key={i} className="up-row border-b border-ink-200 dark:border-[#222A36]">
                <td className="up-td font-mono tabular">{r.hora}</td>
                <td className="up-td font-mono tabular">{r.id}</td>
                <td className="up-td font-medium text-ink-900 dark:text-white">{r.nome}</td>
                <td className="up-td">{r.identif}</td>
                <td className="up-td">{r.inout}</td>
                <td className="up-td">{r.evento}</td>
                <td className="up-td">{r.not}</td>
                <td className="up-td">{r.photo ? "ver" : "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && <DateModal title="Relatório" onClose={() => setShowModal(false)} onSubmit={(v) => {
        setShowModal(false); setMeta(v);
        setRows(window.UPSeed.seedRealtime);
      }} />}
    </div>
  );
};

window.RealtimeScreen = RealtimeScreen;
window.InfoRegScreen = InfoRegScreen;
window.RelatorioScreen = RelatorioScreen;
window.DateModal = DateModal;
