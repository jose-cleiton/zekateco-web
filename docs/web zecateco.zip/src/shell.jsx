// Top bar + Sidebar + Tab strip for Ultraponto

const TopBar = ({ onSearch, onToggleTheme, dark }) => {
  useLucide();
  return (
    <header className="h-12 bg-up-500 text-white flex items-center px-4 shadow-card relative z-30">
      <div className="flex items-center gap-2 font-semibold tracking-tight text-[15px]">
        <span className="inline-flex items-center justify-center w-6 h-6 rounded-md bg-white/15">
          <Icon name="triangle" size={14} />
        </span>
        <span>Ultraponto Webserver</span>
      </div>
      <div className="ml-auto flex items-center gap-1">
        <button className="p-2 hover:bg-white/10 rounded-md" title="Tema" onClick={onToggleTheme}>
          <Icon name={dark ? "sun" : "moon"} size={18} />
        </button>
        <button className="p-2 hover:bg-white/10 rounded-md" title="Buscar" onClick={onSearch}>
          <Icon name="search" size={18} />
        </button>
        <button className="p-2 hover:bg-white/10 rounded-md" title="Mais">
          <Icon name="more-vertical" size={18} />
        </button>
      </div>
    </header>
  );
};

// Menu structure mirrored from the Evo screenshots
const MENU = [
  { id: "home",     label: "Início",      icon: "home",         leaf: true },
  { id: "usuarios", label: "Usuários",    icon: "users",
    children: [
      { id: "novo-usuario", label: "Novo usuário", icon: "user-plus" },
      { id: "lista-usuarios", label: "Usuários",   icon: "list"      }
    ]
  },
  { id: "turno",    label: "Turno",       icon: "calendar",
    children: [
      { id: "turno-cad", label: "Cadastrar turno", icon: "calendar-plus" },
      { id: "turno-list",label: "Lista de turnos", icon: "list-checks" }
    ]
  },
  { id: "relatorio",label: "Relatório",   icon: "bar-chart-3",
    children: [
      { id: "rt",       label: "Registros em tempo real", icon: "activity" },
      { id: "info-reg", label: "Info reg",                icon: "file-text" },
      { id: "rel",      label: "Relatório",               icon: "file-bar-chart" }
    ]
  },
  { id: "sistema",  label: "Sistema",     icon: "log-in",
    children: [
      { id: "dispositivo", label: "Dispositivo", icon: "monitor" },
      { id: "dados",       label: "Dados",       icon: "database" },
      { id: "fw",          label: "Atualizar FW",icon: "upload-cloud" }
    ]
  },
  { id: "bloqueio", label: "Bloqueio",    icon: "lock",
    children: [
      { id: "bloq-list", label: "Lista de bloqueios", icon: "shield-off" },
      { id: "bloq-novo", label: "Novo bloqueio",      icon: "shield-plus" }
    ]
  }
];

const Sidebar = ({ active, openGroups, setOpenGroups, onPick }) => {
  useLucide();
  const isOpen = (id) => openGroups.includes(id);
  const toggle = (id) =>
    setOpenGroups((g) => (g.includes(id) ? g.filter(x => x !== id) : [...g, id]));

  return (
    <aside className="w-60 shrink-0 bg-up-500 up-sidebar-pattern text-white relative">
      {/* Welcome card */}
      <div className="px-3 pt-3">
        <div className="bg-white/10 border border-white/15 rounded-lg px-3 py-2 flex items-center justify-between">
          <div className="leading-tight">
            <div className="text-[11px] uppercase tracking-wide text-white/70">Bem vindo</div>
            <div className="text-[13px] font-semibold">Administrador</div>
          </div>
          <Icon name="chevron-down" size={16} className="text-white/70" />
        </div>
      </div>

      <nav className="mt-3 px-2 pb-4 space-y-0.5">
        {MENU.map(item => {
          const opened = item.children && isOpen(item.id);
          const itemActive = active === item.id || (item.children || []).some(c => c.id === active);
          return (
            <div key={item.id}>
              <button
                onClick={() => item.leaf ? onPick(item.id) : toggle(item.id)}
                className={`w-full flex items-center gap-2.5 h-9 px-3 rounded-md text-[13px] font-medium transition
                            ${itemActive ? "bg-white text-up-700 shadow-sm" : "text-white/95 hover:bg-white/10"}`}
              >
                <Icon name={item.icon} size={16} />
                <span className="flex-1 text-left">{item.label}</span>
                {item.children && (
                  <Icon name={opened ? "minus" : "plus"} size={14} className={itemActive ? "text-up-700" : "text-white/80"} />
                )}
              </button>
              {item.children && opened && (
                <div className="ml-3 mt-0.5 mb-1 pl-3 border-l border-white/20 space-y-0.5">
                  {item.children.map(c => (
                    <button
                      key={c.id}
                      onClick={() => onPick(c.id)}
                      className={`w-full flex items-center gap-2 h-8 pl-2 pr-3 rounded-md text-[12.5px] transition
                                  ${active === c.id ? "bg-white text-up-700 font-semibold" : "text-white/85 hover:bg-white/10"}`}
                    >
                      <Icon name={c.icon} size={13} />
                      <span>{c.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </nav>
    </aside>
  );
};

const TabStrip = ({ tabs, active, onPick, onClose }) => {
  useLucide();
  return (
    <div className="h-10 bg-white border-b border-ink-200 flex items-stretch px-2 dark:bg-[#161B22] dark:border-[#222A36]">
      {tabs.map(t => {
        const isActive = t.id === active;
        return (
          <div
            key={t.id}
            onClick={() => onPick(t.id)}
            className={`relative flex items-center gap-2 px-3 cursor-pointer text-[13px] ${isActive ? "tab-active text-up-600 font-semibold" : "text-ink-500 hover:text-ink-700"}`}
          >
            <span>{t.label}</span>
            {t.closable !== false && (
              <span
                className="tab-x w-4 h-4 inline-flex items-center justify-center text-ink-400"
                onClick={(e) => { e.stopPropagation(); onClose(t.id); }}
              >
                <Icon name="x" size={12} />
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
};

window.TopBar = TopBar;
window.Sidebar = Sidebar;
window.TabStrip = TabStrip;
window.UP_MENU = MENU;
