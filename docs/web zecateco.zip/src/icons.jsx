// Lucide icon helper. We use the global `lucide` UMD and render <i data-lucide="...">
// after each render via a small effect.

const Icon = ({ name, size = 16, className = "", strokeWidth = 1.8, style }) => (
  <i
    data-lucide={name}
    style={{ width: size, height: size, display: "inline-flex", strokeWidth, ...(style || {}) }}
    className={"shrink-0 " + className}
  />
);

function useLucide(deps = []) {
  React.useEffect(() => {
    if (window.lucide && typeof window.lucide.createIcons === "function") {
      try { window.lucide.createIcons(); } catch (e) {}
    }
  });
}

window.Icon = Icon;
window.useLucide = useLucide;
