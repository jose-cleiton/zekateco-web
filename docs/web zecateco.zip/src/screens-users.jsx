// Users list, New user, Edit user

const FaceIcon = ({ size = 140 }) => (
  <svg viewBox="0 0 220 220" width={size} height={size} className="text-ink-700 dark:text-ink-300">
    <g fill="none" stroke="currentColor" strokeWidth="3">
      <path d="M30 30 H72 M30 30 V72" />
      <path d="M190 30 H148 M190 30 V72" />
      <path d="M30 190 H72 M30 190 V148" />
      <path d="M190 190 H148 M190 190 V148" />
    </g>
    <g fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M110 60 c-22 0 -38 18 -38 40 c0 14 6 26 14 33 v8 c-22 6 -34 18 -38 36 h124 c-4 -18 -16 -30 -38 -36 v-8 c8 -7 14 -19 14 -33 c0 -22 -16 -40 -38 -40 z" />
      <path d="M76 100 c8 -22 24 -28 34 -28 c10 0 26 6 34 28" />
    </g>
  </svg>
);

const UserForm = ({ value, onChange, mode = "new" }) => {
  useLucide();
  const set = (k, v) => onChange({ ...value, [k]: v });

  const Field = ({ label, children }) => (
    <div>
      <label className="label">{label}</label>
      {children}
    </div>
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_1fr_260px] gap-x-8 gap-y-3">
      <div className="space-y-3">
        <Field label="ID">
          <input className="field tabular" value={value.id} onChange={e => set("id", e.target.value)} disabled={mode === "edit"} />
        </Field>
        <Field label="Nome">
          <input className="field" value={value.nome} onChange={e => set("nome", e.target.value)} placeholder="Nome completo" />
        </Field>
        <Field label="Depto">
          <input className="field" value={value.depto} onChange={e => set("depto", e.target.value)} />
        </Field>
        <Field label="Cartão">
          <div className="flex gap-2">
            <input className="field flex-1 tabular" value={value.cartao} onChange={e => set("cartao", e.target.value)} placeholder="0" />
            <button className="btn-soft whitespace-nowrap"><Icon name="plus" size={13} />Adicionar no dispositivo</button>
          </div>
        </Field>
        <Field label="Senha">
          <input type="password" className="field" value={value.senha} onChange={e => set("senha", e.target.value)} placeholder="••••••" />
        </Field>
        <Field label="Tipo">
          <select className="field" value={value.tipo} onChange={e => set("tipo", e.target.value)}>
            <option>User</option>
            <option>Admin</option>
            <option>Supervisor</option>
          </select>
        </Field>
      </div>

      <div className="space-y-3">
        <Field label="Turno">
          <input className="field" value={value.turno} onChange={e => set("turno", e.target.value)} />
        </Field>
        <Field label="Faixa">
          <input className="field" value={value.faixa} onChange={e => set("faixa", e.target.value)} />
        </Field>
        <Field label="GRP">
          <input className="field" value={value.grp} onChange={e => set("grp", e.target.value)} />
        </Field>
        <Field label="Modo de verificação pessoal">
          <select className="field" value={value.modo} onChange={e => set("modo", e.target.value)}>
            <option>Modo de verificação do dispositivo</option>
            <option>Face</option>
            <option>Senha</option>
            <option>Cartão</option>
            <option>Multi (Face + Senha)</option>
          </select>
        </Field>
        <Field label="Aniversário">
          <input type="date" className="field" value={value.aniversario} onChange={e => set("aniversario", e.target.value)} />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Início">
            <input type="date" className="field" value={value.inicio} onChange={e => set("inicio", e.target.value)} />
          </Field>
          <Field label="Fim">
            <input type="date" className="field" value={value.fim} onChange={e => set("fim", e.target.value)} />
          </Field>
        </div>
      </div>

      <div className="flex flex-col items-center gap-3">
        <div className="rounded-xl border border-ink-200 dark:border-[#2A3140] bg-ink-50 dark:bg-[#0E1117] p-3">
          <FaceIcon />
        </div>
        <div className="flex flex-col gap-2 w-full">
          <button className="btn-soft justify-start"><Icon name="image" size={13} />Selecione o arquivo</button>
          <button className="btn-soft justify-start"><Icon name="cloud-upload" size={13} />Adicionar no dispositivo</button>
          <button className="btn-danger justify-start"><Icon name="trash-2" size={13} />Excluir</button>
        </div>
      </div>
    </div>
  );
};

const NewUserScreen = ({ onSave }) => {
  const [v, setV] = React.useState({
    id: "1", nome: "", depto: "", cartao: "0", senha: "", tipo: "User",
    turno: "", faixa: "", grp: "", modo: "Modo de verificação do dispositivo",
    aniversario: "", inicio: "", fim: ""
  });
  return (
    <div className="p-6">
      <div className="up-card p-6">
        <UserForm value={v} onChange={setV} mode="new" />
        <div className="flex justify-end gap-2 mt-6 pt-4 border-t border-ink-200 dark:border-[#2A3140]">
          <button className="btn-outline">Cancelar</button>
          <button className="btn-primary" onClick={() => onSave && onSave(v)}>
            <Icon name="check" size={13} /> Salvar usuário
          </button>
        </div>
      </div>
    </div>
  );
};

const EditUserScreen = ({ user, onSave, onClose }) => {
  const [v, setV] = React.useState(user || { id: "—", nome: "", depto: "", cartao: "", senha: "", tipo: "User", turno: "", faixa: "", grp: "", modo: "", aniversario: "", inicio: "", fim: "" });
  return (
    <div className="p-6">
      <div className="up-card p-6">
        <UserForm value={v} onChange={setV} mode="edit" />
        <div className="flex justify-end gap-2 mt-6 pt-4 border-t border-ink-200 dark:border-[#2A3140]">
          <button className="btn-outline" onClick={onClose}>Cancelar</button>
          <button className="btn-primary" onClick={() => onSave && onSave(v)}>
            <Icon name="save" size={13} /> Salvar alterações
          </button>
        </div>
      </div>
    </div>
  );
};

const UsersListScreen = ({ users, onEdit, onDelete, onNew }) => {
  useLucide();
  const [search, setSearch] = React.useState("");
  const [expanded, setExpanded] = React.useState(new Set([28]));
  const [sel, setSel] = React.useState(new Set());
  const [perPage, setPerPage] = React.useState(15);

  const filtered = users.filter(u =>
    !search || u.nome.toLowerCase().includes(search.toLowerCase()) || String(u.id).includes(search)
  );

  const toggleExp = (id) => {
    const s = new Set(expanded);
    s.has(id) ? s.delete(id) : s.add(id);
    setExpanded(s);
  };

  const toggleSel = (id) => {
    const s = new Set(sel);
    s.has(id) ? s.delete(id) : s.add(id);
    setSel(s);
  };

  return (
    <div className="p-6 space-y-3">
      {/* Toolbar */}
      <div className="up-card p-3 flex flex-wrap items-center gap-2">
        <button className="btn-primary" onClick={onNew}><Icon name="user-plus" size={13} />Adicionar</button>
        <button className="btn-danger"><Icon name="trash-2" size={13} />Apagar</button>
        <button className="btn-outline"><Icon name="file-spreadsheet" size={13} />Salvar como Excel</button>
        <button className="btn-outline"><Icon name="upload" size={13} />Importar do Excel</button>
        <button className="btn-outline"><Icon name="download" size={13} />Baixar todas as fotos</button>
        <button className="btn-outline"><Icon name="folder-up" size={13} />Carregar fotos de pastas</button>

        <div className="ml-auto flex items-center gap-2">
          <div className="relative">
            <input className="field pl-8 w-56" placeholder="Search" value={search} onChange={e => setSearch(e.target.value)} />
            <Icon name="search" size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-400" />
          </div>
          <button className="btn-ghost p-2 h-9 w-9 justify-center"><Icon name="calendar" size={14} /></button>
          <button className="btn-ghost p-2 h-9 w-9 justify-center"><Icon name="refresh-cw" size={14} /></button>
          <button className="btn-ghost p-2 h-9 w-9 justify-center"><Icon name="layout-grid" size={14} /></button>
          <button className="btn-ghost p-2 h-9 w-9 justify-center"><Icon name="sliders-horizontal" size={14} /></button>
        </div>
      </div>

      {/* Table */}
      <div className="up-card overflow-hidden">
        <div className="overflow-x-auto nice-scroll">
          <table className="w-full border-collapse min-w-[1100px]">
            <thead>
              <tr className="bg-up-500 text-white">
                <th className="up-th w-8"><input type="checkbox" className="rounded" /></th>
                <th className="up-th w-10"></th>
                <th className="up-th w-20">ID <Icon name="chevrons-up-down" size={11} className="inline ml-0.5 opacity-70" /></th>
                <th className="up-th text-left">Nome</th>
                <th className="up-th">Depto</th>
                <th className="up-th">Turno</th>
                <th className="up-th">Tipo</th>
                <th className="up-th">Face</th>
                <th className="up-th">Senha</th>
                <th className="up-th">Cartão</th>
                <th className="up-th">Faixa</th>
                <th className="up-th">GRP</th>
                <th className="up-th">Modo</th>
                <th className="up-th">Aniversário</th>
                <th className="up-th">Início</th>
                <th className="up-th">Fim</th>
                <th className="up-th">Perfil</th>
                <th className="up-th w-24">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtered.slice(0, perPage).map(u => (
                <React.Fragment key={u.id}>
                  <tr className="up-row border-b border-ink-200 dark:border-[#222A36]">
                    <td className="up-td"><input type="checkbox" checked={sel.has(u.id)} onChange={() => toggleSel(u.id)} className="rounded" /></td>
                    <td className="up-td">
                      <button onClick={() => toggleExp(u.id)} className="w-5 h-5 inline-flex items-center justify-center rounded border border-ink-300 text-ink-500 hover:bg-up-50 hover:text-up-700 hover:border-up-400">
                        <Icon name={expanded.has(u.id) ? "minus" : "plus"} size={11} />
                      </button>
                    </td>
                    <td className="up-td tabular">{u.id}</td>
                    <td className="up-td font-medium text-ink-900 dark:text-white">{u.nome}</td>
                    <td className="up-td text-center">{u.depto || "—"}</td>
                    <td className="up-td text-center">{u.turno}</td>
                    <td className="up-td text-center">
                      <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${u.tipo === 'Admin' ? 'bg-up-100 text-up-700' : 'bg-ink-100 text-ink-700'}`}>{u.tipo}</span>
                    </td>
                    <td className="up-td text-center">{u.face}</td>
                    <td className="up-td text-center">{u.senha}</td>
                    <td className="up-td text-center tabular">{u.cartao}</td>
                    <td className="up-td text-center">{u.faixa}</td>
                    <td className="up-td text-center">{u.grp}</td>
                    <td className="up-td text-center">{u.modo}</td>
                    <td className="up-td text-center tabular">{u.aniversario}</td>
                    <td className="up-td text-center tabular">{u.inicio}</td>
                    <td className="up-td text-center">{u.fim}</td>
                    <td className="up-td text-center">{u.perfil}</td>
                    <td className="up-td">
                      <div className="flex gap-1 justify-end">
                        <button onClick={() => onEdit(u)} className="p-1.5 rounded hover:bg-up-50 text-ink-500 hover:text-up-700" title="Editar"><Icon name="pencil" size={13} /></button>
                        <button onClick={() => onDelete(u.id)} className="p-1.5 rounded hover:bg-rose-50 text-ink-500 hover:text-rose-600" title="Excluir"><Icon name="x" size={13} /></button>
                      </div>
                    </td>
                  </tr>
                  {expanded.has(u.id) && (
                    <tr className="bg-ink-50 dark:bg-[#0E1117] border-b border-ink-200 dark:border-[#222A36]">
                      <td colSpan={18} className="px-6 py-4">
                        <div className="grid grid-cols-2 gap-x-10 gap-y-1 text-[12.5px]">
                          {[["ID", u.id, true], ["Nome", u.nome], ["Depto", u.depto || "—"], ["Turno", u.turno], ["Tipo", u.tipo], ["Senha", u.senha], ["Cartão", u.cartao],
                            ["Faixa", u.faixa], ["GRP", u.grp], ["Modo de verificação pessoal", u.modo], ["Aniversário", u.aniversario], ["Início", u.inicio], ["Fim", u.fim], ["Perfil usuário", u.perfil]
                          ].map(([k, v, mono]) => (
                            <div key={k} className="flex gap-2">
                              <span className="font-semibold text-ink-700 dark:text-ink-300 w-44 shrink-0">{k}:</span>
                              <span className={`text-ink-700 dark:text-ink-300 ${mono ? 'font-mono tabular' : ''}`}>{v}</span>
                            </div>
                          ))}
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
        <div className="p-3 flex items-center justify-between text-[12.5px] text-ink-500 border-t border-ink-200 dark:border-[#222A36]">
          <div>Showing 1 to {Math.min(perPage, filtered.length)} of {filtered.length} rows</div>
          <div className="flex items-center gap-2">
            <select className="field w-16 h-8" value={perPage} onChange={e => setPerPage(+e.target.value)}>
              <option value="10">10</option><option value="15">15</option><option value="25">25</option><option value="50">50</option>
            </select>
            <span>rows per page</span>
          </div>
        </div>
      </div>
    </div>
  );
};

window.NewUserScreen = NewUserScreen;
window.EditUserScreen = EditUserScreen;
window.UsersListScreen = UsersListScreen;
