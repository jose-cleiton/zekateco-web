// Home screen — Porta / Sincronizar hora · Info · Capacidade

const HomeScreen = () => {
  useLucide();
  const d = window.UPSeed.seedDevice;
  const c = window.UPSeed.seedCapacity;

  const [syncing, setSyncing] = React.useState(false);
  const [lastSync, setLastSync] = React.useState(null);
  const [portStatus, setPortStatus] = React.useState("Aberta · 4370");

  const doSync = () => {
    setSyncing(true);
    setTimeout(() => { setSyncing(false); setLastSync(new Date().toLocaleTimeString("pt-BR")); }, 1200);
  };

  const InfoRow = ({ k, v, mono }) => (
    <div className="flex gap-2 py-0.5 text-[13px]">
      <div className="text-ink-700 dark:text-ink-300 font-semibold w-32 shrink-0">{k}:</div>
      <div className={`text-ink-700 dark:text-ink-300 ${mono ? 'font-mono tabular' : ''}`}>{v}</div>
    </div>
  );

  const Bar = ({ used, total, color = "bg-up-500" }) => {
    const pct = Math.max(2, Math.min(100, (used / total) * 100));
    return (
      <div className="h-1.5 w-full bg-ink-200 dark:bg-[#222A36] rounded-full overflow-hidden">
        <div className={`h-full ${color}`} style={{ width: pct + "%" }} />
      </div>
    );
  };

  const CapRow = ({ label, used, total, color }) => (
    <div className="grid grid-cols-[170px_1fr_120px] items-center gap-3 py-2">
      <div className="text-[13px] font-medium text-ink-700 dark:text-ink-300">{label}</div>
      <Bar used={used} total={total} color={color} />
      <div className="text-[12.5px] text-ink-500 text-right tabular">
        <span className="text-ink-900 dark:text-white font-semibold">{used.toLocaleString("pt-BR")}</span>
        <span className="text-ink-400"> / {total.toLocaleString("pt-BR")}</span>
      </div>
    </div>
  );

  return (
    <div className="p-6 space-y-6">
      {/* Action row */}
      <div className="up-card p-4 flex flex-wrap items-center gap-3">
        <button className="btn-primary">
          <Icon name="plug" size={14} /> Porta
        </button>
        <button className={`btn-soft ${syncing ? "opacity-70" : ""}`} onClick={doSync}>
          <Icon name="refresh-cw" size={14} className={syncing ? "animate-spin" : ""} />
          Sincronizar hora
        </button>
        <div className="ml-auto flex items-center gap-2 text-[12.5px] text-ink-500">
          <span className="inline-flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 pulse-dot"></span>
            Porta {portStatus}
          </span>
          {lastSync && <span className="text-ink-400">· última sincronização {lastSync}</span>}
        </div>
      </div>

      {/* Info card */}
      <div className="up-card p-5">
        <div className="soft-frame">
          <span className="soft-tag">Info</span>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 mt-1">
            <div>
              <InfoRow k="Nome" v={d.nome || "AiFace"} />
              <InfoRow k="Num. Serie" v={d.serial} mono />
              <InfoRow k="ID" v={d.id} mono />
              <InfoRow k="Firmware" v={d.firmware} mono />
            </div>
            <div>
              <InfoRow k="Hora" v={d.hora} mono />
              <InfoRow k="IP" v={d.ip} mono />
              <InfoRow k="MAC Address" v={d.mac} mono />
              <InfoRow k="Local" v={d.local} />
              <InfoRow k="Questionário" v={d.questionario} />
            </div>
          </div>
        </div>
      </div>

      {/* Capacity card */}
      <div className="up-card p-5">
        <div className="soft-frame">
          <span className="soft-tag">Capacidade</span>
          <CapRow label="Usuários"            used={c.usuarios.used}  total={c.usuarios.total}  color="bg-up-500" />
          <CapRow label="Face"                used={c.face.used}      total={c.face.total}      color="bg-up-500" />
          <CapRow label="Cartão"              used={c.cartao.used}    total={c.cartao.total}    color="bg-up-400" />
          <CapRow label="Senha"               used={c.senha.used}     total={c.senha.total}     color="bg-up-400" />
          <div className="my-2 border-t border-dashed border-ink-200 dark:border-[#2A3140]" />
          <CapRow label="Todos os registros"  used={c.registros.used} total={c.registros.total} color="bg-emerald-500" />
        </div>
      </div>
    </div>
  );
};

window.HomeScreen = HomeScreen;
