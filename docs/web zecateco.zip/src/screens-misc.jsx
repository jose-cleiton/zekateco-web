// Turno + Bloqueio — secondary screens

const TurnoScreen = () => {
  useLucide();
  const turnos = [
    { id: 1, nome: "Comercial", inicio: "08:00", fim: "18:00", almoco: "12:00–13:00", dias: "Seg–Sex", ativo: true },
    { id: 2, nome: "Diurno",    inicio: "06:00", fim: "14:00", almoco: "10:00–10:30", dias: "Seg–Sáb", ativo: true },
    { id: 3, nome: "Noturno",   inicio: "22:00", fim: "06:00", almoco: "02:00–02:30", dias: "Seg–Sex", ativo: true },
    { id: 4, nome: "Sábado",    inicio: "08:00", fim: "12:00", almoco: "—",            dias: "Sáb",     ativo: false }
  ];

  return (
    <div className="p-6 space-y-3">
      <div className="up-card p-3 flex items-center gap-2">
        <button className="btn-primary"><Icon name="calendar-plus" size={13} /> Cadastrar turno</button>
        <button className="btn-outline"><Icon name="copy" size={13} /> Duplicar</button>
        <span className="ml-auto text-[12.5px] text-ink-500">{turnos.length} turnos cadastrados</span>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {turnos.map(t => (
          <div key={t.id} className="up-card p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-up-50 text-up-600 flex items-center justify-center"><Icon name="clock" size={18} /></div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h4 className="text-[14px] font-semibold">{t.nome}</h4>
                  <span className={`text-[10.5px] font-semibold px-2 py-0.5 rounded-full ${t.ativo ? 'bg-emerald-50 text-emerald-700' : 'bg-ink-100 text-ink-500'}`}>{t.ativo ? "Ativo" : "Inativo"}</span>
                </div>
                <div className="text-[12px] text-ink-500">{t.dias}</div>
              </div>
              <button className="p-1.5 rounded hover:bg-up-50 text-ink-500 hover:text-up-700"><Icon name="pencil" size={13} /></button>
            </div>
            <div className="grid grid-cols-3 gap-3 mt-3 text-[12.5px]">
              <div>
                <div className="text-ink-500">Início</div>
                <div className="font-semibold tabular">{t.inicio}</div>
              </div>
              <div>
                <div className="text-ink-500">Fim</div>
                <div className="font-semibold tabular">{t.fim}</div>
              </div>
              <div>
                <div className="text-ink-500">Almoço</div>
                <div className="font-semibold tabular">{t.almoco}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const BloqueioScreen = ({ subkey = "bloq-list" }) => {
  useLucide();
  const blocks = [
    { id: 1, usuario: "Anderson Santana",  motivo: "Suspensão temporária", inicio: "20/04/2026", fim: "27/04/2026", status: "Ativo" },
    { id: 2, usuario: "Caio Alves",        motivo: "Férias",                inicio: "01/05/2026", fim: "20/05/2026", status: "Agendado" }
  ];
  return (
    <div className="p-6 space-y-3">
      <div className="up-card p-3 flex items-center gap-2">
        <button className="btn-primary"><Icon name="shield-plus" size={13} /> Novo bloqueio</button>
        <span className="ml-auto text-[12.5px] text-ink-500">{blocks.length} bloqueios</span>
      </div>
      <div className="up-card overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-up-500 text-white">
              <th className="up-th text-left w-12">#</th>
              <th className="up-th text-left">Usuário</th>
              <th className="up-th text-left">Motivo</th>
              <th className="up-th text-left">Início</th>
              <th className="up-th text-left">Fim</th>
              <th className="up-th text-left">Status</th>
              <th className="up-th w-24">Ações</th>
            </tr>
          </thead>
          <tbody>
            {blocks.map(b => (
              <tr key={b.id} className="up-row border-b border-ink-200 dark:border-[#222A36]">
                <td className="up-td tabular">{b.id}</td>
                <td className="up-td font-medium text-ink-900 dark:text-white">{b.usuario}</td>
                <td className="up-td">{b.motivo}</td>
                <td className="up-td tabular">{b.inicio}</td>
                <td className="up-td tabular">{b.fim}</td>
                <td className="up-td">
                  <span className={`text-[11.5px] font-semibold px-2 py-0.5 rounded-full ${b.status === 'Ativo' ? 'bg-rose-50 text-rose-700' : 'bg-amber-50 text-amber-700'}`}>{b.status}</span>
                </td>
                <td className="up-td text-right">
                  <button className="p-1.5 rounded hover:bg-up-50 text-ink-500 hover:text-up-700"><Icon name="pencil" size={13} /></button>
                  <button className="p-1.5 rounded hover:bg-rose-50 text-ink-500 hover:text-rose-600"><Icon name="x" size={13} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

window.TurnoScreen = TurnoScreen;
window.BloqueioScreen = BloqueioScreen;
