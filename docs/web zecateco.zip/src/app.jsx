// Main Ultraponto app — wires shell + screens with tab system + dark mode tweaks

const { useState, useEffect } = React;

// Map screen ids to their breadcrumb labels (mirrors MENU)
const LABELS = {
  "home": "Início",
  "novo-usuario": "Novo usuário",
  "lista-usuarios": "Usuários",
  "edit-usuario": "Editar",
  "turno-cad": "Cadastrar turno",
  "turno-list": "Lista de turnos",
  "rt": "Registros em tempo real",
  "info-reg": "Info reg",
  "rel": "Relatório",
  "dispositivo": "Dispositivo",
  "dados": "Dados",
  "fw": "Atualizar FW",
  "bloq-list": "Bloqueios",
  "bloq-novo": "Novo bloqueio"
};

const TWEAKS_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAKS_DEFAULTS);
  const [tabs, setTabs] = useState([{ id: "home", label: "Início", closable: false }]);
  const [active, setActive] = useState("home");
  const [openGroups, setOpenGroups] = useState(["usuarios", "relatorio", "sistema"]);
  const [users, setUsers] = useState(window.UPSeed.seedUsers);
  const [editingUser, setEditingUser] = useState(null);

  // Apply theme
  useEffect(() => {
    const html = document.documentElement;
    if (tweaks.theme === "dark") html.classList.add("dark"); else html.classList.remove("dark");
  }, [tweaks.theme]);

  const openScreen = (id, opts = {}) => {
    const label = opts.label || LABELS[id] || id;
    setTabs(t => {
      if (t.some(x => x.id === id)) return t;
      return [...t, { id, label, closable: id !== "home" }];
    });
    setActive(id);
  };

  const closeTab = (id) => {
    setTabs(t => {
      const next = t.filter(x => x.id !== id);
      if (active === id) {
        const fallback = next[next.length - 1] || next[0];
        setActive(fallback ? fallback.id : "home");
      }
      return next;
    });
  };

  const handleNewUser = (v) => {
    const id = parseInt(v.id) || (Math.max(...users.map(u => u.id)) + 1);
    setUsers([...users, { ...v, id, perfil: v.tipo === "Admin" ? "Admin" : "Padrão", face: "Não" }]);
    closeTab("novo-usuario");
    openScreen("lista-usuarios");
  };

  const handleEditOpen = (user) => {
    setEditingUser(user);
    openScreen("edit-usuario", { label: "Editar" });
  };

  const handleEditSave = (v) => {
    setUsers(prev => prev.map(u => u.id === v.id ? { ...u, ...v } : u));
    setEditingUser(null);
    closeTab("edit-usuario");
  };

  const handleDelete = (id) => {
    if (window.confirm("Excluir este usuário?")) {
      setUsers(prev => prev.filter(u => u.id !== id));
    }
  };

  const renderScreen = () => {
    switch (active) {
      case "home":           return <HomeScreen />;
      case "novo-usuario":   return <NewUserScreen onSave={handleNewUser} />;
      case "lista-usuarios": return <UsersListScreen users={users} onEdit={handleEditOpen} onDelete={handleDelete} onNew={() => openScreen("novo-usuario")} />;
      case "edit-usuario":   return <EditUserScreen user={editingUser} onSave={handleEditSave} onClose={() => closeTab("edit-usuario")} />;
      case "turno-cad":
      case "turno-list":     return <TurnoScreen />;
      case "rt":             return <RealtimeScreen />;
      case "info-reg":       return <InfoRegScreen />;
      case "rel":            return <RelatorioScreen />;
      case "dispositivo":    return <DispositivoScreen />;
      case "dados":          return <DadosScreen />;
      case "fw":             return <FwScreen />;
      case "bloq-list":
      case "bloq-novo":      return <BloqueioScreen subkey={active} />;
      default:               return <div className="p-6 text-ink-500">Tela não implementada: {active}</div>;
    }
  };

  return (
    <div className="h-screen flex flex-col">
      <TopBar
        dark={tweaks.theme === "dark"}
        onToggleTheme={() => setTweak("theme", tweaks.theme === "dark" ? "light" : "dark")}
        onSearch={() => alert("Busca global — em breve")}
      />
      <div className="flex flex-1 min-h-0">
        <Sidebar
          active={active}
          openGroups={openGroups}
          setOpenGroups={setOpenGroups}
          onPick={(id) => openScreen(id)}
        />
        <main className="flex-1 min-w-0 flex flex-col bg-ink-50 dark:bg-[#0E1117]">
          <TabStrip tabs={tabs} active={active} onPick={setActive} onClose={closeTab} />
          <div className="flex-1 min-h-0 overflow-auto nice-scroll" data-screen-label={LABELS[active] || active}>
            {renderScreen()}
          </div>
        </main>
      </div>

      {/* Tweaks panel */}
      <TweaksPanel title="Tweaks">
        <TweakSection title="Aparência">
          <TweakRadio
            label="Tema"
            value={tweaks.theme}
            onChange={(v) => setTweak("theme", v)}
            options={[{ value: "light", label: "Claro" }, { value: "dark", label: "Escuro" }]}
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
