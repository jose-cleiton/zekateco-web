// Mock state + seed data for the Ultraponto prototype

const seedDevice = {
  name: "AiFace",
  serial: "AYSJ14003196",
  id: "1",
  firmware: "ai806_f06v_v5.06",
  hora: "2026-04-26 08:23:37",
  ip: "192.168.001.063",
  mac: "00-01-A9-1B-16-D8",
  local: "Wi-Fi",
  questionario: "Sim"
};

const seedCapacity = {
  usuarios:   { used: 2,  total: 15000 },
  face:       { used: 1,  total: 15000 },
  cartao:     { used: 0,  total: 15000 },
  senha:      { used: 0,  total: 15000 },
  registros:  { used: 83, total: 500000 }
};

const seedUsers = [
  { id: 28,     nome: "Jamile Goncalves de Oliveira", depto: "RH",        turno: "Comercial", tipo: "User",  face: "Sim", senha: "—", cartao: "—", faixa: "—", grp: "—", modo: "Auto",  aniversario: "1995-05-12", inicio: "2022-01-10", fim: "—", perfil: "Padrão" },
  { id: 153867, nome: "José Cleiton Santos",          depto: "TI",        turno: "Adm",       tipo: "Admin", face: "Sim", senha: "Sim", cartao: "—", faixa: "—", grp: "—", modo: "Face",  aniversario: "1992-10-03", inicio: "2021-03-22", fim: "—", perfil: "Admin"  },
  { id: 412,    nome: "Anderson Santana",             depto: "Logística", turno: "Noturno",   tipo: "User",  face: "Não", senha: "Sim", cartao: "0019283", faixa: "B", grp: "G2", modo: "Cartão", aniversario: "1988-02-19", inicio: "2024-08-01", fim: "—", perfil: "Padrão" },
  { id: 87,     nome: "Bonifacio Jovi",               depto: "Financeiro",turno: "Comercial", tipo: "User",  face: "Sim", senha: "—", cartao: "—", faixa: "—", grp: "G1", modo: "Auto",  aniversario: "1991-07-30", inicio: "2023-11-14", fim: "—", perfil: "Padrão" },
  { id: 91,     nome: "Caio Alves",                   depto: "RH",        turno: "Comercial", tipo: "User",  face: "Sim", senha: "—", cartao: "—", faixa: "—", grp: "G1", modo: "Auto",  aniversario: "1996-09-08", inicio: "2024-02-02", fim: "—", perfil: "Padrão" },
  { id: 102,    nome: "Daniela Coelho",               depto: "Financeiro",turno: "Comercial", tipo: "User",  face: "Sim", senha: "Sim", cartao: "00833201", faixa: "—", grp: "G1", modo: "Multi", aniversario: "1990-12-17", inicio: "2020-06-01", fim: "—", perfil: "Padrão" },
  { id: 144,    nome: "Gustavo Trindade",             depto: "Logística", turno: "Diurno",    tipo: "User",  face: "Não", senha: "Sim", cartao: "—", faixa: "A", grp: "G3", modo: "Senha", aniversario: "1985-04-26", inicio: "2019-09-13", fim: "—", perfil: "Padrão" }
];

// Real-time access logs (Registros em tempo real)
const baseTime = new Date("2026-04-26T08:23:37");
const logEvents = ["Entrada","Saída","Almoço","Retorno","Entrada","Saída"];
const seedRealtime = [
  { hora:"2026-04-26 08:23:11", id:28,     nome:"Jamile Goncalves de Oliveira", identif:"Face",   inout:"in",  evento:"Entrada", not:"OK", photo:true  },
  { hora:"2026-04-26 08:21:52", id:153867, nome:"José Cleiton Santos",          identif:"Face",   inout:"in",  evento:"Entrada", not:"OK", photo:true  },
  { hora:"2026-04-26 08:19:33", id:412,    nome:"Anderson Santana",             identif:"Cartão", inout:"in",  evento:"Entrada", not:"OK", photo:false },
  { hora:"2026-04-26 08:15:08", id:87,     nome:"Bonifacio Jovi",               identif:"Face",   inout:"in",  evento:"Entrada", not:"OK", photo:true  },
  { hora:"2026-04-26 08:12:41", id:91,     nome:"Caio Alves",                   identif:"Face",   inout:"in",  evento:"Entrada", not:"OK", photo:true  },
  { hora:"2026-04-26 08:11:02", id:102,    nome:"Daniela Coelho",               identif:"Senha",  inout:"in",  evento:"Entrada", not:"OK", photo:false },
  { hora:"2026-04-26 08:08:55", id:144,    nome:"Gustavo Trindade",             identif:"Senha",  inout:"in",  evento:"Entrada", not:"OK", photo:false }
];

window.UPSeed = { seedDevice, seedCapacity, seedUsers, seedRealtime };
