// System: Dispositivo · Dados · Atualizar FW

const DispositivoScreen = () => {
  useLucide();
  const d = window.UPSeed.seedDevice;
  const SettingRow = ({ icon, label, hint, control }) => (
    <div className="flex items-center gap-3 py-3 border-b border-ink-200 dark:border-[#222A36] last:border-0">
      <div className="w-9 h-9 rounded-lg bg-up-50 text-up-600 flex items-center justify-center"><Icon name={icon} size={15} /></div>
      <div className="flex-1">
        <div className="text-[13px] font-semibold text-ink-900 dark:text-white">{label}</div>
        {hint && <div className="text-[12px] text-ink-500">{hint}</div>}
      </div>
      <div>{control}</div>
    </div>
  );

  return (
    <div className="p-6 grid grid-cols-1 xl:grid-cols-2 gap-4">
      <div className="up-card p-5">
        <h3 className="text-[14px] font-semibold text-ink-900 dark:text-white mb-3">Identificação</h3>
        <SettingRow icon="hash"        label="Número de série"   control={<span className="font-mono tabular text-[13px]">{d.serial}</span>} />
        <SettingRow icon="cpu"         label="Firmware"          control={<span className="font-mono tabular text-[13px]">{d.firmware}</span>} />
        <SettingRow icon="globe"       label="Endereço IP"       control={<span className="font-mono tabular text-[13px]">{d.ip}</span>} />
        <SettingRow icon="wifi"        label="Conexão"           control={<span className="text-[12.5px] font-medium bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full">{d.local}</span>} />
        <SettingRow icon="clock"       label="Hora do dispositivo" hint="Sincronize com o servidor" control={<button className="btn-soft">Sincronizar</button>} />
      </div>

      <div className="up-card p-5">
        <h3 className="text-[14px] font-semibold text-ink-900 dark:text-white mb-3">Configurações</h3>
        <SettingRow icon="volume-2"    label="Volume do alto-falante" control={<input type="range" min="0" max="100" defaultValue="70" className="w-40 accent-up-500" />} />
        <SettingRow icon="moon"        label="Modo descanso"          hint="Após 5 minutos sem atividade" control={<input type="checkbox" defaultChecked className="toggle accent-up-500 w-4 h-4" />} />
        <SettingRow icon="scan-face"   label="Distância mínima de face" control={
          <select className="field w-32"><option>30 cm</option><option>50 cm</option><option>80 cm</option></select>
        } />
        <SettingRow icon="key-round"   label="Senha de administração" control={<button className="btn-outline">Alterar</button>} />
        <SettingRow icon="rotate-ccw"  label="Reiniciar dispositivo" hint="Reset suave (mantém dados)" control={<button className="btn-outline">Reiniciar</button>} />
      </div>
    </div>
  );
};

const DadosScreen = () => {
  useLucide();
  return (
    <div className="p-6 grid grid-cols-1 xl:grid-cols-3 gap-4">
      <div className="up-card p-5 xl:col-span-2">
        <h3 className="text-[14px] font-semibold text-ink-900 dark:text-white mb-3">Backup & Restauração</h3>
        <div className="space-y-3">
          {[
            { i: "database", t: "Backup completo do banco de dados", h: "Inclui usuários, registros e fotos.", b: "Gerar backup" },
            { i: "upload", t: "Restaurar a partir de arquivo .db", h: "Substitui os dados atuais.", b: "Selecionar arquivo" },
            { i: "trash-2", t: "Limpar todos os registros", h: "Mantém usuários cadastrados.", b: "Limpar", danger: true }
          ].map(r => (
            <div key={r.t} className="flex items-center gap-3 p-3 rounded-lg border border-ink-200 dark:border-[#222A36]">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${r.danger ? 'bg-rose-50 text-rose-600' : 'bg-up-50 text-up-600'}`}><Icon name={r.i} size={15} /></div>
              <div className="flex-1">
                <div className="text-[13px] font-semibold">{r.t}</div>
                <div className="text-[12px] text-ink-500">{r.h}</div>
              </div>
              <button className={r.danger ? "btn-danger" : "btn-soft"}>{r.b}</button>
            </div>
          ))}
        </div>
      </div>

      <div className="up-card p-5">
        <h3 className="text-[14px] font-semibold text-ink-900 dark:text-white mb-3">Estatísticas do banco</h3>
        <ul className="text-[13px] divide-y divide-ink-200 dark:divide-[#222A36]">
          {[["Tamanho atual", "907 KB"], ["Última cópia", "26/04/2026 06:00"], ["Registros", "83"], ["Usuários", "2"], ["Fotos", "1"]].map(([k, v]) => (
            <li key={k} className="flex justify-between py-2"><span className="text-ink-500">{k}</span><span className="font-semibold tabular">{v}</span></li>
          ))}
        </ul>
      </div>
    </div>
  );
};

const FwScreen = () => {
  useLucide();
  const [progress, setProgress] = React.useState(null);
  const start = () => {
    setProgress(0);
    const id = setInterval(() => {
      setProgress(p => {
        if (p >= 100) { clearInterval(id); return 100; }
        return Math.min(100, p + 4 + Math.random() * 6);
      });
    }, 200);
  };
  return (
    <div className="p-6 grid grid-cols-1 xl:grid-cols-2 gap-4">
      <div className="up-card p-5">
        <h3 className="text-[14px] font-semibold mb-3">Atualizar firmware</h3>
        <p className="text-[12.5px] text-ink-500 mb-3">Selecione um arquivo .bin compatível com o modelo AiFace · Firmware atual: <span className="font-mono">{window.UPSeed.seedDevice.firmware}</span></p>
        <div className="border-2 border-dashed border-ink-200 dark:border-[#222A36] rounded-xl p-6 flex flex-col items-center justify-center text-center">
          <div className="w-12 h-12 rounded-xl bg-up-50 text-up-600 flex items-center justify-center mb-2"><Icon name="upload-cloud" size={22} /></div>
          <div className="text-[13px] font-semibold">Solte o arquivo aqui</div>
          <div className="text-[12px] text-ink-500">ou</div>
          <button className="btn-soft mt-2">Selecionar arquivo</button>
        </div>
        <div className="flex justify-end mt-4 gap-2">
          <button className="btn-outline">Cancelar</button>
          <button className="btn-primary" onClick={start}><Icon name="zap" size={13} /> Iniciar atualização</button>
        </div>
        {progress !== null && (
          <div className="mt-4">
            <div className="flex justify-between text-[12px] text-ink-500 mb-1"><span>Atualizando…</span><span className="tabular">{Math.round(progress)}%</span></div>
            <div className="h-2 bg-ink-200 dark:bg-[#222A36] rounded-full overflow-hidden">
              <div className="h-full bg-up-500 transition-all" style={{ width: progress + "%" }} />
            </div>
          </div>
        )}
      </div>

      <div className="up-card p-5">
        <h3 className="text-[14px] font-semibold mb-3">Histórico de versões</h3>
        <ul className="space-y-3 text-[13px]">
          {[
            { v: "ai806_f06v_v5.06", d: "26/04/2026", c: "Versão atual",  ok: true },
            { v: "ai806_f06v_v5.04", d: "12/02/2026", c: "Estável" },
            { v: "ai806_f06v_v5.02", d: "30/11/2025", c: "Estável" },
            { v: "ai806_f06v_v4.98", d: "01/09/2025", c: "Legado" }
          ].map(h => (
            <li key={h.v} className="flex items-center gap-3">
              <div className={`w-2 h-2 rounded-full ${h.ok ? 'bg-emerald-500' : 'bg-ink-300'}`}></div>
              <div className="flex-1">
                <div className="font-mono tabular">{h.v}</div>
                <div className="text-[11.5px] text-ink-500">{h.d} · {h.c}</div>
              </div>
              {h.ok && <span className="text-[11px] font-semibold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full">Em uso</span>}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

window.DispositivoScreen = DispositivoScreen;
window.DadosScreen = DadosScreen;
window.FwScreen = FwScreen;
